self.addEventListener('push', e=>{
  const data = e.data.json()
  self.registration.showNotification('Title', 'Test');
})